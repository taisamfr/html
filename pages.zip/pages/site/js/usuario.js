document.addEventListener("DOMContentLoaded", () => {
  initLogin();
  initRegister();
  initProfile();
});

function initLogin() {
  if (currentPage() !== "login.html") return;
  document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.target));
    try {
      const response = await apiFetch(ENDPOINTS.login, { method: "POST", body: JSON.stringify(body) });
      const user = response.usuario || response.user || response;
      setUser(user);
      showToast("Login realizado com sucesso.");
      setTimeout(() => {
        window.location.href = normalizeRole(user.perfil) === "ADMIN" ? "admin.html" : "index.html";
      }, 700);
    } catch (error) {
      showToast(error.message, "error");
    }
  });
}

function initRegister() {
  if (currentPage() !== "cadastro.html") return;
  document.getElementById("registerForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.target));
    try {
      await apiFetch(ENDPOINTS.usuarios, { method: "POST", body: JSON.stringify(body) });
      showToast("Cadastro realizado. Entre para continuar.");
      setTimeout(() => (window.location.href = "login.html"), 900);
    } catch (error) {
      showToast(error.message, "error");
    }
  });
}

async function initProfile() {
  if (currentPage() !== "perfil.html") return;
  const user = requireAuth();
  if (!user) return;
  try {
    const fresh = await apiFetch(`${ENDPOINTS.usuarios}/${getUserId(user)}`);
    fillProfile(fresh);
  } catch {
    fillProfile(user);
  }
  document.getElementById("profileForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const body = Object.fromEntries(new FormData(event.target));
    try {
      const updated = await apiFetch(`${ENDPOINTS.usuarios}/${getUserId(user)}`, { method: "PUT", body: JSON.stringify(body) });
      setUser(updated);
      showToast("Perfil atualizado com sucesso.");
    } catch (error) {
      showToast(error.message, "error");
    }
  });
}

function fillProfile(user) {
  const form = document.getElementById("profileForm");
  Object.entries(user || {}).forEach(([key, value]) => {
    if (form.elements[key]) form.elements[key].value = value ?? "";
  });
}
