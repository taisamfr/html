document.addEventListener("DOMContentLoaded", initOrders);

async function initOrders() {
  if (currentPage() !== "pedidos.html") return;
  const user = requireAuth();
  if (!user) return;
  await loadOrders(user);
}

async function loadOrders(user) {
  const wrap = document.getElementById("ordersList");
  wrap.innerHTML = `<p class="text-slate-500">Carregando pedidos...</p>`;
  try {
    const orders = await apiFetch(`${ENDPOINTS.pedidos}/usuario/${getUserId(user)}`);
    if (!orders.length) {
      wrap.innerHTML = `<div class="empty-state">Voce ainda nao tem pedidos.</div>`;
      return;
    }
    wrap.innerHTML = orders.map((order) => `
      <article class="panel">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p class="text-sm font-bold text-emerald-600">Pedido #${getOrderId(order)}</p>
            <h3 class="mt-1 text-xl font-black text-slate-950">${order.status || "Em andamento"}</h3>
            <p class="mt-1 text-sm text-slate-500">${formatDate(order.dataPedido || order.criadoEm || order.data)}</p>
          </div>
          <div class="text-right">
            <p class="text-sm text-slate-500">Valor total</p>
            <p class="text-2xl font-black text-slate-950">${formatCurrency(order.valorTotal || order.total)}</p>
          </div>
        </div>
      </article>
    `).join("");
  } catch (error) {
    showToast(error.message, "error");
    wrap.innerHTML = `<p class="text-red-600">Nao foi possivel carregar os pedidos.</p>`;
  }
}

