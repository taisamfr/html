const SESSION_KEY = "animalia_usuario";

function getUser() {
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY));
  } catch {
    return null;
  }
}

function setUser(user) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

function logout() {
  localStorage.removeItem(SESSION_KEY);
  showToast("Sessao encerrada.", "success");
  setTimeout(() => (window.location.href = "index.html"), 700);
}

function requireAuth() {
  const user = getUser();
  if (!user) {
    window.location.href = "login.html";
    return null;
  }
  return user;
}

function requireAdmin() {
  const user = requireAuth();
  if (user && normalizeRole(user.perfil) !== "ADMIN") {
    window.location.href = "index.html";
  }
  return user;
}

function normalizeRole(role) {
  return String(role || "USER").toUpperCase();
}

async function apiFetch(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(options.headers || {})
    }
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    const message = typeof data === "string" ? data : data?.message || data?.erro || "Nao foi possivel concluir a operacao.";
    throw new Error(message);
  }

  return data;
}

function formatCurrency(value) {
  return Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatDate(value) {
  if (!value) return "Data indisponivel";
  return new Date(value).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function getProductId(product) {
  return product?.id ?? product?.idProduto ?? product?.produtoId;
}

function getCategoryId(category) {
  return category?.id ?? category?.idCategoria;
}

function getUserId(user) {
  return user?.id ?? user?.idUsuario ?? user?.usuarioId;
}

function getOrderId(order) {
  return order?.id ?? order?.idPedido ?? order?.pedidoId;
}

function getItemId(item) {
  return item?.id ?? item?.idItemPedido ?? item?.itemPedidoId;
}

function getProductImage(product) {
  const id = getProductId(product);
  if (product?.imagemUrl) return product.imagemUrl;
  if (product?.imagem) return product.imagem;
  return id ? `${ENDPOINTS.produtos}/${id}/imagem` : "";
}

function currentPage() {
  return window.location.pathname.split("/").pop() || "index.html";
}

function renderNavbar() {
  const user = getUser();
  const isAdmin = normalizeRole(user?.perfil) === "ADMIN";
  const nav = document.getElementById("navbar");
  if (!nav) return;

  nav.innerHTML = `
    <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
      <a href="index.html" class="flex items-center gap-3">
        <span class="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500 text-xl font-black text-white shadow-soft">A</span>
        <span class="leading-tight">
          <span class="block text-lg font-black text-slate-950">Animalia</span>
          <span class="block text-xs font-semibold uppercase tracking-wide text-emerald-600">PetShop</span>
        </span>
      </a>
      <button id="menuToggle" class="icon-btn md:hidden" aria-label="Abrir menu">☰</button>
      <div id="navLinks" class="hidden items-center gap-2 md:flex">
        <a class="nav-link" href="index.html">Loja</a>
        ${user ? `<a class="nav-link" href="perfil.html">Perfil</a><a class="nav-link" href="pedidos.html">Pedidos</a>` : ""}
        ${isAdmin ? `<a class="nav-link" href="admin.html">Admin</a>` : ""}
        <a class="nav-link relative" href="carrinho.html">Carrinho <span id="cartBadge" class="badge">0</span></a>
        ${user ? `<button class="btn-secondary" onclick="logout()">Sair</button>` : `<a class="btn-secondary" href="login.html">Entrar</a><a class="btn-primary" href="cadastro.html">Cadastrar</a>`}
      </div>
    </div>
    <div id="mobileLinks" class="hidden border-t border-slate-200 bg-white px-4 py-3 md:hidden">
      <a class="mobile-link" href="index.html">Loja</a>
      ${user ? `<a class="mobile-link" href="perfil.html">Perfil</a><a class="mobile-link" href="pedidos.html">Pedidos</a>` : ""}
      ${isAdmin ? `<a class="mobile-link" href="admin.html">Admin</a>` : ""}
      <a class="mobile-link" href="carrinho.html">Carrinho</a>
      ${user ? `<button class="mobile-link text-left" onclick="logout()">Sair</button>` : `<a class="mobile-link" href="login.html">Entrar</a><a class="mobile-link" href="cadastro.html">Cadastrar</a>`}
    </div>
  `;

  document.getElementById("menuToggle")?.addEventListener("click", () => {
    document.getElementById("mobileLinks")?.classList.toggle("hidden");
  });
  updateCartBadge();
}

function renderFooter() {
  const footer = document.getElementById("footer");
  if (!footer) return;
  footer.innerHTML = `
    <div class="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
      <div>
        <h3 class="text-lg font-black text-white">Animalia PetShop</h3>
        <p class="mt-3 text-sm text-emerald-50">Produtos, cuidado e carinho para a rotina do seu pet.</p>
      </div>
      <div>
        <h4 class="footer-title">Loja</h4>
        <a href="index.html" class="footer-link">Produtos</a>
        <a href="carrinho.html" class="footer-link">Carrinho</a>
        <a href="pedidos.html" class="footer-link">Pedidos</a>
      </div>
      <div>
        <h4 class="footer-title">Conta</h4>
        <a href="login.html" class="footer-link">Entrar</a>
        <a href="cadastro.html" class="footer-link">Criar conta</a>
        <a href="perfil.html" class="footer-link">Meu perfil</a>
      </div>
      <div>
        <h4 class="footer-title">Atendimento</h4>
        <p class="text-sm text-emerald-50">Segunda a sabado, das 8h as 20h.</p>
        <p class="mt-2 text-sm text-emerald-50">contato@animalia.local</p>
      </div>
    </div>
  `;
}

function showToast(message, type = "success") {
  let box = document.getElementById("toastBox");
  if (!box) {
    box = document.createElement("div");
    box.id = "toastBox";
    box.className = "fixed right-4 top-4 z-50 flex w-[calc(100%-2rem)] max-w-sm flex-col gap-3";
    document.body.appendChild(box);
  }
  const item = document.createElement("div");
  item.className = `toast ${type === "error" ? "toast-error" : "toast-success"}`;
  item.textContent = message;
  box.appendChild(item);
  setTimeout(() => item.remove(), 4200);
}

function openModal({ title, body, onConfirm, confirmText = "Salvar" }) {
  const wrap = document.createElement("div");
  wrap.className = "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4";
  wrap.innerHTML = `
    <div class="w-full max-w-xl rounded-3xl bg-white p-6 shadow-2xl">
      <div class="flex items-start justify-between gap-4">
        <h3 class="text-xl font-black text-slate-950">${title}</h3>
        <button class="icon-btn" data-close aria-label="Fechar">×</button>
      </div>
      <div class="mt-5">${body}</div>
      <div class="mt-6 flex justify-end gap-3">
        <button class="btn-secondary" data-close>Cancelar</button>
        <button class="btn-primary" data-confirm>${confirmText}</button>
      </div>
    </div>
  `;
  document.body.appendChild(wrap);
  wrap.querySelectorAll("[data-close]").forEach((btn) => btn.addEventListener("click", () => wrap.remove()));
  wrap.querySelector("[data-confirm]").addEventListener("click", async () => {
    await onConfirm?.(wrap);
  });
}

async function updateCartBadge() {
  const badge = document.getElementById("cartBadge");
  const user = getUser();
  if (!badge || !user) {
    if (badge) badge.textContent = "0";
    return;
  }
  try {
    const pedido = await apiFetch(`${ENDPOINTS.pedidos}/carrinho/${getUserId(user)}`);
    const itens = pedido?.itens || pedido?.itensPedido || [];
    badge.textContent = itens.reduce((sum, item) => sum + Number(item.quantidade || 0), 0);
  } catch {
    badge.textContent = "0";
  }
}

function productCard(product) {
  const id = getProductId(product);
  const price = product.preco_desconto || product.precoDesconto || product.preco;
  const original = product.preco_desconto || product.precoDesconto ? product.preco : null;
  return `
    <article class="product-card">
      <a href="#" class="block overflow-hidden rounded-2xl bg-slate-100">
        <img class="h-48 w-full object-cover transition duration-300 hover:scale-105" src="${getProductImage(product)}" alt="${product.nome || "Produto"}" onerror="this.src='https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=700&q=80'">
      </a>
      <div class="mt-4 flex min-h-[160px] flex-col">
        <p class="text-xs font-bold uppercase tracking-wide text-emerald-600">${product.categoria?.nome || product.nomeCategoria || "Pet shop"}</p>
        <h3 class="mt-1 line-clamp-2 text-base font-black text-slate-950">${product.nome || "Produto"}</h3>
        <p class="mt-2 line-clamp-2 text-sm text-slate-500">${product.descricao || "Produto selecionado para o cuidado diario do seu pet."}</p>
        <div class="mt-auto flex items-end justify-between gap-3 pt-4">
          <div>
            ${original ? `<p class="text-xs text-slate-400 line-through">${formatCurrency(original)}</p>` : ""}
            <p class="text-lg font-black text-emerald-600">${formatCurrency(price)}</p>
          </div>
          <button class="btn-primary whitespace-nowrap" data-add-cart="${id}">Adicionar</button>
        </div>
      </div>
    </article>
  `;
}

async function addToCart(produtoId, quantidade = 1) {
  const user = requireAuth();
  if (!user) return;
  const params = new URLSearchParams({ usuarioId: getUserId(user), produtoId, quantidade });
  await apiFetch(`${ENDPOINTS.itensPedido}/adicionar?${params}`, { method: "POST" });
  showToast("Produto adicionado ao carrinho.");
  updateCartBadge();
}

document.addEventListener("DOMContentLoaded", () => {
  renderNavbar();
  renderFooter();
});

