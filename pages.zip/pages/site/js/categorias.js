async function getCategorias() {
  return apiFetch(ENDPOINTS.categorias);
}

