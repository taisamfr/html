let currentCart = null;

document.addEventListener("DOMContentLoaded", initCart);

async function initCart() {
  if (currentPage() !== "carrinho.html") return;
  requireAuth();
  await loadCart();
}

async function loadCart() {
  const user = getUser();
  const container = document.getElementById("cartItems");
  container.innerHTML = `<p class="text-slate-500">Carregando carrinho...</p>`;
  try {
    currentCart = await apiFetch(`${ENDPOINTS.pedidos}/carrinho/${getUserId(user)}`);
    renderCart(currentCart);
  } catch (error) {
    showToast(error.message, "error");
    container.innerHTML = `<p class="text-red-600">Nao foi possivel carregar o carrinho.</p>`;
  }
}

function renderCart(cart) {
  const container = document.getElementById("cartItems");
  const items = cart?.itens || cart?.itensPedido || [];
  if (!items.length) {
    container.innerHTML = `<div class="empty-state">Seu carrinho esta vazio.</div>`;
    updateTotals([]);
    return;
  }
  container.innerHTML = items.map((item) => {
    const product = item.produto || item.product || {};
    const price = product.preco_desconto || product.precoDesconto || product.preco || item.precoUnitario || 0;
    return `
      <article class="cart-row">
        <img class="h-24 w-24 rounded-2xl object-cover" src="${getProductImage(product)}" alt="${product.nome || "Produto"}" onerror="this.src='https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=400&q=80'">
        <div class="min-w-0 flex-1">
          <h3 class="font-black text-slate-950">${product.nome || item.nomeProduto || "Produto"}</h3>
          <p class="mt-1 text-sm text-slate-500">${formatCurrency(price)}</p>
          <div class="mt-4 flex flex-wrap items-center gap-3">
            <button class="qty-btn" data-item="${getItemId(item)}" data-product="${getProductId(product)}" data-value="${Number(item.quantidade || 1) - 1}">-</button>
            <span class="w-8 text-center font-bold">${item.quantidade || 1}</span>
            <button class="qty-btn" data-item="${getItemId(item)}" data-product="${getProductId(product)}" data-value="${Number(item.quantidade || 1) + 1}">+</button>
            <button class="text-sm font-bold text-red-600" data-remove="${getItemId(item)}">Remover</button>
          </div>
        </div>
        <strong class="text-lg text-slate-950">${formatCurrency(price * Number(item.quantidade || 1))}</strong>
      </article>
    `;
  }).join("");
  bindCartActions();
  updateTotals(items);
}

function updateTotals(items) {
  const subtotal = items.reduce((sum, item) => {
    const product = item.produto || {};
    const price = product.preco_desconto || product.precoDesconto || product.preco || item.precoUnitario || 0;
    return sum + price * Number(item.quantidade || 1);
  }, 0);
  document.getElementById("subtotal").textContent = formatCurrency(subtotal);
  document.getElementById("total").textContent = formatCurrency(subtotal);
}

function bindCartActions() {
  document.querySelectorAll("[data-product]").forEach((button) => {
    button.addEventListener("click", async () => {
      const quantity = Number(button.dataset.value);
      try {
        await apiFetch(`${ENDPOINTS.itensPedido}/${button.dataset.item}/pedido/${getOrderId(currentCart)}`, { method: "DELETE" });
        if (quantity > 0) {
          await addToCart(button.dataset.product, quantity);
        } else {
          showToast("Item removido do carrinho.");
        }
        await loadCart();
        updateCartBadge();
      } catch (error) {
        showToast(error.message, "error");
      }
    });
  });

  document.querySelectorAll("[data-remove]").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await apiFetch(`${ENDPOINTS.itensPedido}/${button.dataset.remove}/pedido/${getOrderId(currentCart)}`, { method: "DELETE" });
        showToast("Item removido do carrinho.");
        await loadCart();
        updateCartBadge();
      } catch (error) {
        showToast(error.message, "error");
      }
    });
  });
}

document.getElementById("finishOrder")?.addEventListener("click", async () => {
  try {
    await apiFetch(`${ENDPOINTS.pedidos}/finalizar/${getOrderId(currentCart)}`, { method: "PUT" });
    showToast("Pedido finalizado com sucesso.");
    setTimeout(() => (window.location.href = "pedidos.html"), 900);
  } catch (error) {
    showToast(error.message, "error");
  }
});
