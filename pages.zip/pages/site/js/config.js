const API_URL = "http://localhost:8080";

const ENDPOINTS = {
  usuarios: `${API_URL}/usuarios`,
  login: `${API_URL}/usuarios/login`,
  categorias: `${API_URL}/api/categorias`,
  produtos: `${API_URL}/api/produtos`,
  itensPedido: `${API_URL}/api/itens-pedido`,
  pedidos: `${API_URL}/api/pedidos`
};

