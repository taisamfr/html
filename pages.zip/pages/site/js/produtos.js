let allProducts = [];
let allCategories = [];
let activeCategory = "all";

document.addEventListener("DOMContentLoaded", initHome);

async function initHome() {
  if (currentPage() !== "index.html") return;
  bindHomeEvents();
  await Promise.all([loadCategories(), loadProducts()]);
}

function bindHomeEvents() {
  document.getElementById("searchForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const term = document.getElementById("searchInput").value.trim();
    if (!term) return loadProducts();
    await searchProducts(term);
  });

  document.getElementById("clearFilters")?.addEventListener("click", () => {
    activeCategory = "all";
    document.getElementById("searchInput").value = "";
    renderProducts(allProducts);
    renderCategoryFilters();
  });

  document.addEventListener("click", async (event) => {
    const addButton = event.target.closest("[data-add-cart]");
    if (addButton) {
      try {
        await addToCart(addButton.dataset.addCart, 1);
      } catch (error) {
        showToast(error.message, "error");
      }
    }
  });
}

async function loadProducts() {
  const grid = document.getElementById("productsGrid");
  if (grid) grid.innerHTML = `<p class="col-span-full text-slate-500">Carregando produtos...</p>`;
  try {
    allProducts = await apiFetch(ENDPOINTS.produtos);
    renderProducts(allProducts);
    renderFeaturedProducts(allProducts.slice(0, 4));
  } catch (error) {
    showToast(error.message, "error");
    grid.innerHTML = `<p class="col-span-full text-red-600">Nao foi possivel carregar os produtos.</p>`;
  }
}

async function searchProducts(term) {
  try {
    const products = await apiFetch(`${ENDPOINTS.produtos}/buscar?nome=${encodeURIComponent(term)}`);
    renderProducts(products);
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function loadCategories() {
  try {
    allCategories = await apiFetch(ENDPOINTS.categorias);
    renderCategoryFilters();
    renderCategoryHighlights();
  } catch (error) {
    showToast(error.message, "error");
  }
}

function renderProducts(products) {
  const grid = document.getElementById("productsGrid");
  if (!grid) return;
  if (!products?.length) {
    grid.innerHTML = `<p class="col-span-full rounded-3xl bg-white p-8 text-center text-slate-500 shadow-soft">Nenhum produto encontrado.</p>`;
    return;
  }
  grid.innerHTML = products.map(productCard).join("");
}

function renderFeaturedProducts(products) {
  const grid = document.getElementById("featuredGrid");
  if (!grid) return;
  grid.innerHTML = products?.length ? products.map(productCard).join("") : `<p class="col-span-full text-slate-500">Nenhum destaque disponivel.</p>`;
}

function renderCategoryFilters() {
  const wrap = document.getElementById("categoryFilters");
  if (!wrap) return;
  const buttons = [
    `<button class="filter-chip ${activeCategory === "all" ? "filter-active" : ""}" data-category-filter="all">Todos</button>`,
    ...allCategories.map((cat) => `<button class="filter-chip ${String(activeCategory) === String(getCategoryId(cat)) ? "filter-active" : ""}" data-category-filter="${getCategoryId(cat)}">${cat.nome}</button>`)
  ];
  wrap.innerHTML = buttons.join("");
  wrap.querySelectorAll("[data-category-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      activeCategory = button.dataset.categoryFilter;
      renderCategoryFilters();
      if (activeCategory === "all") return renderProducts(allProducts);
      try {
        const products = await apiFetch(`${ENDPOINTS.produtos}/categoria/${activeCategory}`);
        renderProducts(products);
      } catch (error) {
        showToast(error.message, "error");
      }
    });
  });
}

function renderCategoryHighlights() {
  const wrap = document.getElementById("categoryHighlights");
  if (!wrap) return;
  wrap.innerHTML = allCategories.slice(0, 6).map((category) => `
    <button class="category-card text-left" data-scroll-category="${getCategoryId(category)}">
      <span class="category-icon">${(category.nome || "P").slice(0, 1).toUpperCase()}</span>
      <span class="mt-4 block text-lg font-black text-slate-950">${category.nome}</span>
      <span class="mt-1 block text-sm text-slate-500">Ver produtos</span>
    </button>
  `).join("");
  wrap.querySelectorAll("[data-scroll-category]").forEach((button) => {
    button.addEventListener("click", () => {
      document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
      setTimeout(() => document.querySelector(`[data-category-filter="${button.dataset.scrollCategory}"]`)?.click(), 250);
    });
  });
}

