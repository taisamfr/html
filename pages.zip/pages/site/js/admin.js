let adminData = { produtos: [], categorias: [], usuarios: [], pedidos: [] };

document.addEventListener("DOMContentLoaded", initAdmin);

async function initAdmin() {
  if (currentPage() !== "admin.html") return;
  requireAdmin();
  bindAdminNav();
  await loadAdminData();
}

function bindAdminNav() {
  document.querySelectorAll("[data-admin-tab]").forEach((button) => {
    button.addEventListener("click", () => showAdminTab(button.dataset.adminTab));
  });
}

function showAdminTab(tab) {
  document.querySelectorAll("[data-admin-panel]").forEach((panel) => panel.classList.toggle("hidden", panel.dataset.adminPanel !== tab));
  document.querySelectorAll("[data-admin-tab]").forEach((btn) => btn.classList.toggle("admin-tab-active", btn.dataset.adminTab === tab));
}

async function loadAdminData() {
  try {
    const [produtos, categorias, usuarios] = await Promise.all([
      apiFetch(ENDPOINTS.produtos),
      apiFetch(ENDPOINTS.categorias),
      apiFetch(ENDPOINTS.usuarios)
    ]);
    const pedidosPorUsuario = await Promise.allSettled(
      usuarios.map((usuario) => apiFetch(`${ENDPOINTS.pedidos}/usuario/${getUserId(usuario)}`))
    );
    const pedidos = pedidosPorUsuario.flatMap((result) => result.status === "fulfilled" ? result.value : []);
    adminData = { ...adminData, produtos, categorias, usuarios, pedidos };
    renderDashboard();
    renderAdminProducts();
    renderAdminCategories();
    renderAdminUsers();
    renderAdminOrders(pedidos);
  } catch (error) {
    showToast(error.message, "error");
  }
}

function renderDashboard() {
  document.getElementById("totalProdutos").textContent = adminData.produtos.length;
  document.getElementById("totalUsuarios").textContent = adminData.usuarios.length;
  document.getElementById("totalPedidos").textContent = adminData.pedidos.length;
}

function renderAdminProducts() {
  const wrap = document.getElementById("adminProducts");
  wrap.innerHTML = `
    <div class="mb-4 flex justify-end"><button class="btn-primary" onclick="openProductModal()">Novo produto</button></div>
    ${table(["Produto", "Preco", "Estoque", "Acoes"], adminData.produtos.map((p) => [
      p.nome,
      formatCurrency(p.preco),
      p.qtd_estoque ?? p.qtdEstoque ?? 0,
      `<button class="link-action" onclick='openProductModal(${JSON.stringify(getProductId(p))})'>Editar</button>
       <button class="link-danger" onclick="deleteProduct(${getProductId(p)})">Excluir</button>`
    ]))}
  `;
}

function renderAdminCategories() {
  const wrap = document.getElementById("adminCategories");
  wrap.innerHTML = `
    <div class="mb-4 flex justify-end"><button class="btn-primary" onclick="openCategoryModal()">Nova categoria</button></div>
    ${table(["Categoria", "Acoes"], adminData.categorias.map((c) => [
      c.nome,
      `<button class="link-action" onclick='openCategoryModal(${JSON.stringify(getCategoryId(c))})'>Editar</button>
       <button class="link-danger" onclick="deleteCategory(${getCategoryId(c)})">Excluir</button>`
    ]))}
  `;
}

function renderAdminUsers() {
  const wrap = document.getElementById("adminUsers");
  wrap.innerHTML = table(["Nome", "Email", "Perfil", "Acoes"], adminData.usuarios.map((u) => [
    u.nome,
    u.email,
    u.perfil || "USER",
    `<button class="link-action" onclick='openUserModal(${JSON.stringify(getUserId(u))})'>Editar</button>
     <button class="link-danger" onclick="deleteUser(${getUserId(u)})">Excluir</button>`
  ]));
}

function renderAdminOrders(orders) {
  const wrap = document.getElementById("adminOrders");
  wrap.innerHTML = orders.length ? table(["Pedido", "Status", "Total", "Acoes"], orders.map((o) => [
    `#${getOrderId(o)}`,
    o.status,
    formatCurrency(o.valorTotal || o.total),
    `<button class="link-danger" onclick="cancelOrder(${getOrderId(o)})">Cancelar</button>`
  ])) : `<div class="empty-state">Nenhum pedido encontrado.</div>`;
}

function table(headers, rows) {
  return `
    <div class="overflow-x-auto rounded-3xl border border-slate-200 bg-white">
      <table class="min-w-full divide-y divide-slate-200 text-sm">
        <thead class="bg-slate-50"><tr>${headers.map((h) => `<th class="px-4 py-3 text-left font-black text-slate-600">${h}</th>`).join("")}</tr></thead>
        <tbody class="divide-y divide-slate-100">${rows.map((row) => `<tr>${row.map((cell) => `<td class="px-4 py-3 align-middle">${cell ?? ""}</td>`).join("")}</tr>`).join("")}</tbody>
      </table>
    </div>
  `;
}

function openProductModal(id) {
  const product = adminData.produtos.find((p) => String(getProductId(p)) === String(id)) || {};
  const options = adminData.categorias.map((c) => `<option value="${getCategoryId(c)}" ${String(product.id_categoria || product.idCategoria || product.categoria?.id) === String(getCategoryId(c)) ? "selected" : ""}>${c.nome}</option>`).join("");
  openModal({
    title: id ? "Editar produto" : "Novo produto",
    body: `
      <form id="productForm" class="form-grid">
        <input class="input" name="nome" placeholder="Nome" value="${product.nome || ""}" required>
        <input class="input" name="preco" placeholder="Preco" type="number" step="0.01" value="${product.preco || ""}" required>
        <input class="input" name="preco_desconto" placeholder="Preco com desconto" type="number" step="0.01" value="${product.preco_desconto || product.precoDesconto || ""}">
        <input class="input" name="qtd_estoque" placeholder="Estoque" type="number" value="${product.qtd_estoque || product.qtdEstoque || ""}" required>
        <select class="input" name="id_categoria" required>${options}</select>
        <textarea class="input sm:col-span-2" name="descricao" placeholder="Descricao">${product.descricao || ""}</textarea>
        <input class="input sm:col-span-2" name="imagem" type="file" accept="image/*">
      </form>
    `,
    onConfirm: async (modal) => saveProduct(id, modal)
  });
}

async function saveProduct(id, modal) {
  const form = document.getElementById("productForm");
  const data = new FormData(form);
  try {
    await apiFetch(id ? `${ENDPOINTS.produtos}/${id}` : ENDPOINTS.produtos, { method: id ? "PUT" : "POST", body: data });
    showToast(id ? "Produto atualizado." : "Produto criado.");
    modal.remove();
    await loadAdminData();
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function deleteProduct(id) {
  if (!confirm("Excluir este produto?")) return;
  try {
    await apiFetch(`${ENDPOINTS.produtos}/${id}`, { method: "DELETE" });
    showToast("Produto excluido.");
    await loadAdminData();
  } catch (error) {
    showToast(error.message, "error");
  }
}

function openCategoryModal(id) {
  const category = adminData.categorias.find((c) => String(getCategoryId(c)) === String(id)) || {};
  openModal({
    title: id ? "Editar categoria" : "Nova categoria",
    body: `<form id="categoryForm"><input class="input" name="nome" placeholder="Nome da categoria" value="${category.nome || ""}" required></form>`,
    onConfirm: async (modal) => {
      const body = Object.fromEntries(new FormData(document.getElementById("categoryForm")));
      try {
        await apiFetch(id ? `${ENDPOINTS.categorias}/${id}` : ENDPOINTS.categorias, { method: id ? "PUT" : "POST", body: JSON.stringify(body) });
        showToast(id ? "Categoria atualizada." : "Categoria criada.");
        modal.remove();
        await loadAdminData();
      } catch (error) {
        showToast(error.message, "error");
      }
    }
  });
}

async function deleteCategory(id) {
  if (!confirm("Excluir esta categoria?")) return;
  try {
    await apiFetch(`${ENDPOINTS.categorias}/${id}`, { method: "DELETE" });
    showToast("Categoria excluida.");
    await loadAdminData();
  } catch (error) {
    showToast(error.message, "error");
  }
}

function openUserModal(id) {
  const user = adminData.usuarios.find((u) => String(getUserId(u)) === String(id)) || {};
  openModal({
    title: "Editar usuario",
    body: `
      <form id="userForm" class="form-grid">
        ${["nome","email","endereco","bairro","complemento","cep","cidade","estado"].map((field) => `<input class="input" name="${field}" placeholder="${field}" value="${user[field] || ""}">`).join("")}
        <select class="input" name="perfil"><option ${normalizeRole(user.perfil) === "USER" ? "selected" : ""}>USER</option><option ${normalizeRole(user.perfil) === "ADMIN" ? "selected" : ""}>ADMIN</option></select>
      </form>
    `,
    onConfirm: async (modal) => {
      const body = Object.fromEntries(new FormData(document.getElementById("userForm")));
      try {
        await apiFetch(`${ENDPOINTS.usuarios}/${id}`, { method: "PUT", body: JSON.stringify(body) });
        showToast("Usuario atualizado.");
        modal.remove();
        await loadAdminData();
      } catch (error) {
        showToast(error.message, "error");
      }
    }
  });
}

async function deleteUser(id) {
  if (!confirm("Excluir este usuario?")) return;
  try {
    await apiFetch(`${ENDPOINTS.usuarios}/${id}`, { method: "DELETE" });
    showToast("Usuario excluido.");
    await loadAdminData();
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function cancelOrder(id) {
  try {
    await apiFetch(`${ENDPOINTS.pedidos}/${id}/cancelar`, { method: "PUT" });
    showToast("Pedido cancelado.");
  } catch (error) {
    showToast(error.message, "error");
  }
}
